<style lang="scss">
    .back{
        opacity: .8;
        position: fixed;
        height: 50px;
        width: 50px;
        bottom: 20px;
        right: 30px;
    }
</style>

<template>
   <div class="back">
      <a href="index.html">
          <img src="./back.png" alt="返回">
      </a>
    </div>
</template>

<script>
export default {
  
}
</script>
